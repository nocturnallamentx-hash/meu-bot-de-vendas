# 📦 Guia de Instalação Completo

Este guia irá te ajudar a configurar o bot de vendas do zero.

## 🎯 Passo 1: Preparação

### Requisitos do Sistema
- **Node.js** versão 16.0.0 ou superior
- **npm** (vem com o Node.js)
- **Conta Discord** com permissões de administrador no servidor
- **Conta Mercado Pago** para processar pagamentos

### Downloads Necessários
1. [Node.js](https://nodejs.org/) - Baixe a versão LTS
2. [Git](https://git-scm.com/) (opcional, mas recomendado)

## 🤖 Passo 2: Configuração do Bot Discord

### 2.1 Criar Aplicação Discord
1. Acesse [Discord Developer Portal](https://discord.com/developers/applications)
2. Clique em "New Application"
3. Digite um nome para seu bot (ex: "Loja Bot")
4. Clique em "Create"

### 2.2 Configurar o Bot
1. No menu lateral, clique em "Bot"
2. Clique em "Add Bot" → "Yes, do it!"
3. **IMPORTANTE**: Copie o token e guarde em local seguro
4. Desative "Public Bot" se quiser que apenas você possa adicionar o bot
5. Ative as seguintes "Privileged Gateway Intents":
   - ✅ Presence Intent
   - ✅ Server Members Intent
   - ✅ Message Content Intent

### 2.3 Obter IDs Necessários
1. **Client ID**: Na aba "General Information", copie o "Application ID"
2. **Guild ID**: 
   - Ative o "Modo Desenvolvedor" no Discord (Configurações → Avançado → Modo Desenvolvedor)
   - Clique com botão direito no seu servidor → "Copiar ID"

### 2.4 Adicionar Bot ao Servidor
1. Vá para "OAuth2" → "URL Generator"
2. Selecione:
   - **Scopes**: `bot` e `applications.commands`
   - **Bot Permissions**:
     - ✅ Read Messages/View Channels
     - ✅ Send Messages
     - ✅ Manage Messages
     - ✅ Embed Links
     - ✅ Attach Files
     - ✅ Read Message History
     - ✅ Use Slash Commands
     - ✅ Manage Channels
     - ✅ Manage Roles
     - ✅ Send Messages in Threads
3. Copie a URL gerada e abra no navegador
4. Selecione seu servidor e autorize

## 💳 Passo 3: Configuração do Mercado Pago

### 3.1 Criar Conta de Desenvolvedor
1. Acesse [Mercado Pago Developers](https://www.mercadopago.com.br/developers)
2. Faça login com sua conta Mercado Pago
3. Vá em "Suas integrações" → "Criar aplicação"

### 3.2 Configurar Aplicação
1. **Nome**: Digite um nome para sua aplicação
2. **Modelo de negócio**: Selecione "Marketplace"
3. **Produtos**: Selecione "Pagamentos online"
4. Clique em "Criar aplicação"

### 3.3 Obter Credenciais
1. Na sua aplicação, vá para "Credenciais"
2. **Para testes**: Use as credenciais de "Sandbox"
3. **Para produção**: Use as credenciais de "Produção"
4. Copie:
   - **Access Token**
   - **Public Key**

## 🛠️ Passo 4: Instalação do Bot

### 4.1 Extrair Arquivos
1. Extraia o arquivo ZIP do bot
2. Abra o terminal/prompt na pasta extraída

### 4.2 Instalar Dependências
```bash
npm install
```

### 4.3 Configurar Variáveis de Ambiente
1. Copie o arquivo de exemplo:
```bash
cp .env.example .env
```

2. Edite o arquivo `.env` com suas credenciais:
```env
# Discord Bot Configuration
DISCORD_TOKEN=SEU_TOKEN_DISCORD_AQUI
CLIENT_ID=SEU_CLIENT_ID_AQUI
GUILD_ID=SEU_GUILD_ID_AQUI

# Mercado Pago Configuration
MERCADO_PAGO_ACCESS_TOKEN=SEU_ACCESS_TOKEN_AQUI
MERCADO_PAGO_PUBLIC_KEY=SUA_PUBLIC_KEY_AQUI

# Database Configuration
DATABASE_PATH=./database.sqlite

# Server Configuration
PORT=3000
HOST=0.0.0.0

# Bot Configuration
PREFIX=!
ADMIN_ROLE_ID=ID_DO_CARGO_ADMIN
SUPPORT_CATEGORY_ID=ID_DA_CATEGORIA_SUPORTE
WELCOME_CHANNEL_ID=ID_DO_CANAL_BOAS_VINDAS
LOGS_CHANNEL_ID=ID_DO_CANAL_LOGS
```

## 🏗️ Passo 5: Configuração do Servidor Discord

### 5.1 Criar Estrutura de Canais
Crie os seguintes canais no seu servidor:

```
📋 INFORMAÇÕES
├── 📜 regras
├── 📢 anúncios
└── 👋 boas-vindas

🛒 LOJA
├── 🛍️ produtos
└── 💳 pagamentos

🎫 SUPORTE (Categoria)
├── 📞 criar-ticket
└── (tickets serão criados automaticamente aqui)

👥 GERAL
├── 💬 chat-geral
└── 🎮 comandos-bot
```

### 5.2 Configurar Cargos
1. Crie um cargo "Verificado" para usuários verificados
2. Crie um cargo "Admin" para administradores
3. Configure as permissões adequadas

### 5.3 Obter IDs dos Canais
1. Com o modo desenvolvedor ativo
2. Clique com botão direito nos canais/categorias
3. Selecione "Copiar ID"
4. Adicione os IDs no arquivo `.env`

## 🚀 Passo 6: Iniciar o Bot

### 6.1 Primeira Execução
```bash
npm start
```

### 6.2 Verificar se Funcionou
1. O bot deve aparecer online no Discord
2. Teste o comando `/loja` em um canal
3. Acesse `http://localhost:3000` para ver o painel

### 6.3 Para Desenvolvimento
```bash
npm run dev
```
(Reinicia automaticamente quando você faz alterações)

## ✅ Passo 7: Configuração Inicial

### 7.1 Criar Primeiro Produto
1. Use o comando `/produto criar` ou
2. Acesse o painel web em `http://localhost:3000`

### 7.2 Configurar Painéis
```bash
/verificacao painel    # Cria painel de verificação
/suporte painel       # Cria painel de suporte
/loja                 # Mostra a loja
```

### 7.3 Testar Funcionalidades
1. Teste a verificação de usuários
2. Teste a criação de tickets
3. Teste uma compra (use credenciais de teste)

## 🔧 Passo 8: Configurações Avançadas

### 8.1 Webhook do Mercado Pago (Opcional)
Para pagamentos automáticos em produção:

1. No painel do Mercado Pago, vá em "Webhooks"
2. Adicione: `https://seu-dominio.com/webhook/mercadopago`
3. Selecione eventos de pagamento

### 8.2 Hospedagem (Opcional)
Para manter o bot online 24/7:

**Opções gratuitas:**
- Heroku
- Railway
- Render

**Opções pagas:**
- DigitalOcean
- AWS
- Google Cloud

## 🐛 Solução de Problemas Comuns

### Bot não aparece online
- ✅ Verifique se o token está correto
- ✅ Confirme se o bot foi adicionado ao servidor
- ✅ Verifique se não há erros no console

### Comandos não funcionam
- ✅ Aguarde alguns minutos (comandos podem demorar para registrar)
- ✅ Verifique se o bot tem permissões de "Use Slash Commands"
- ✅ Tente reiniciar o bot

### Erro de permissões
- ✅ Verifique se o cargo do bot está acima dos outros cargos
- ✅ Confirme se o bot tem as permissões necessárias
- ✅ Verifique as permissões do canal específico

### Pagamentos não funcionam
- ✅ Verifique se as credenciais do Mercado Pago estão corretas
- ✅ Confirme se está usando credenciais de teste para testes
- ✅ Verifique os logs do console para erros

### Banco de dados não funciona
- ✅ Verifique se a pasta tem permissões de escrita
- ✅ Confirme se o SQLite está instalado corretamente
- ✅ Tente deletar o arquivo `database.sqlite` e reiniciar

## 📞 Precisa de Ajuda?

### Logs de Debug
Para ver logs detalhados:
```bash
npm run dev
```

### Verificar Configuração
Use o comando `/config info` para ver se tudo está configurado.

### Arquivos de Log
Verifique o console do terminal para mensagens de erro detalhadas.

---

**🎉 Parabéns! Seu bot de vendas está pronto para usar!**

Agora você pode:
- ✅ Criar produtos
- ✅ Processar pagamentos
- ✅ Gerenciar cupons
- ✅ Oferecer suporte via tickets
- ✅ Dar boas-vindas automáticas

**Próximos passos:**
1. Adicione seus primeiros produtos
2. Configure as mensagens de boas-vindas
3. Teste todas as funcionalidades
4. Comece a vender! 🚀

