const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('loja')
        .setDescription('Exibe a loja de produtos'),
    
    async execute(interaction, database) {
        try {
            const products = await database.getAllProducts();
            
            if (products.length === 0) {
                return await interaction.reply({ 
                    content: 'Nenhum produto disponível no momento.', 
                    ephemeral: true 
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('🛒 Loja de Produtos')
                .setDescription('Confira nossos produtos disponíveis:')
                .setColor('#0099ff')
                .setTimestamp();

            const buttons = [];
            
            for (const product of products.slice(0, 5)) { // Máximo 5 produtos por mensagem
                embed.addFields({
                    name: `${product.name} - R$ ${product.price.toFixed(2)}`,
                    value: `${product.description}\n**Estoque:** ${product.stock} unidades`,
                    inline: true
                });

                if (product.stock > 0) {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId(`buy_${product.id}`)
                            .setLabel(`Comprar ${product.name}`)
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('💳')
                    );
                }
            }

            const components = [];
            if (buttons.length > 0) {
                // Dividir botões em grupos de 5 (limite do Discord)
                for (let i = 0; i < buttons.length; i += 5) {
                    const row = new ActionRowBuilder()
                        .addComponents(buttons.slice(i, i + 5));
                    components.push(row);
                }
            }

            await interaction.reply({ 
                embeds: [embed], 
                components: components 
            });
        } catch (error) {
            console.error('Erro no comando loja:', error);
            await interaction.reply({ 
                content: 'Erro ao carregar a loja!', 
                ephemeral: true 
            });
        }
    },
};

