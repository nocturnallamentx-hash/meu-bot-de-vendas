const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('config')
        .setDescription('Configurações do bot')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('info')
                .setDescription('Mostrar informações de configuração'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('Estatísticas do bot')),
    
    async execute(interaction, database) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'info':
                    await this.showConfig(interaction);
                    break;
                case 'stats':
                    await this.showStats(interaction, database);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando config:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async showConfig(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('⚙️ Configurações do Bot')
            .setDescription('Informações sobre a configuração atual do bot.')
            .addFields(
                { name: 'Prefix', value: process.env.PREFIX || '!', inline: true },
                { name: 'Porta do Servidor', value: process.env.PORT || '3000', inline: true },
                { name: 'Canal de Boas-vindas', value: process.env.WELCOME_CHANNEL_ID ? `<#${process.env.WELCOME_CHANNEL_ID}>` : 'Não configurado', inline: true },
                { name: 'Canal de Logs', value: process.env.LOGS_CHANNEL_ID ? `<#${process.env.LOGS_CHANNEL_ID}>` : 'Não configurado', inline: true },
                { name: 'Categoria de Suporte', value: process.env.SUPPORT_CATEGORY_ID ? `<#${process.env.SUPPORT_CATEGORY_ID}>` : 'Não configurado', inline: true },
                { name: 'Cargo de Admin', value: process.env.ADMIN_ROLE_ID ? `<@&${process.env.ADMIN_ROLE_ID}>` : 'Não configurado', inline: true }
            )
            .setColor('#0099ff')
            .setTimestamp();

        // Verificar se o Mercado Pago está configurado
        const mpConfigured = process.env.MERCADO_PAGO_ACCESS_TOKEN ? '✅ Configurado' : '❌ Não configurado';
        embed.addFields({ name: 'Mercado Pago', value: mpConfigured, inline: true });

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async showStats(interaction, database) {
        try {
            // Buscar estatísticas do banco
            const totalProducts = await database.all('SELECT COUNT(*) as count FROM products WHERE active = 1');
            const totalSales = await database.all('SELECT COUNT(*) as count FROM sales');
            const totalRevenue = await database.all('SELECT SUM(amount) as total FROM sales WHERE status = "approved"');
            const totalCoupons = await database.all('SELECT COUNT(*) as count FROM coupons WHERE active = 1');
            const totalTickets = await database.all('SELECT COUNT(*) as count FROM tickets');
            const pendingSales = await database.all('SELECT COUNT(*) as count FROM sales WHERE status = "pending"');

            const embed = new EmbedBuilder()
                .setTitle('📊 Estatísticas do Bot')
                .setDescription('Estatísticas gerais do sistema de vendas.')
                .addFields(
                    { name: '📦 Produtos Ativos', value: totalProducts[0].count.toString(), inline: true },
                    { name: '💰 Total de Vendas', value: totalSales[0].count.toString(), inline: true },
                    { name: '💵 Receita Total', value: `R$ ${(totalRevenue[0].total || 0).toFixed(2)}`, inline: true },
                    { name: '🎫 Cupons Ativos', value: totalCoupons[0].count.toString(), inline: true },
                    { name: '🎫 Total de Tickets', value: totalTickets[0].count.toString(), inline: true },
                    { name: '⏳ Vendas Pendentes', value: pendingSales[0].count.toString(), inline: true }
                )
                .setColor('#00ff00')
                .setTimestamp();

            // Adicionar informações do servidor
            const guild = interaction.guild;
            embed.addFields(
                { name: '👥 Membros do Servidor', value: guild.memberCount.toString(), inline: true },
                { name: '📅 Bot Online desde', value: interaction.client.readyAt.toLocaleDateString('pt-BR'), inline: true }
            );

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error('Erro ao buscar estatísticas:', error);
            await interaction.reply({ 
                content: 'Erro ao carregar estatísticas!', 
                ephemeral: true 
            });
        }
    }
};

