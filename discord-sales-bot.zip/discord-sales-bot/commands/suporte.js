const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('suporte')
        .setDescription('Sistema de suporte e tickets')
        .addSubcommand(subcommand =>
            subcommand
                .setName('painel')
                .setDescription('Criar painel de suporte'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tickets')
                .setDescription('Listar todos os tickets')
                .setDefaultMemberPermissions(PermissionFlagsBits.Administrator))
        .addSubcommand(subcommand =>
            subcommand
                .setName('fechar')
                .setDescription('Fechar ticket atual')
                .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)),
    
    async execute(interaction, database) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'painel':
                    await this.createSupportPanel(interaction);
                    break;
                case 'tickets':
                    await this.listTickets(interaction, database);
                    break;
                case 'fechar':
                    await this.closeTicket(interaction, database);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando suporte:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async createSupportPanel(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🎫 Central de Suporte')
            .setDescription('Precisa de ajuda? Clique em um dos botões abaixo para criar um ticket de suporte.')
            .addFields(
                { name: '💰 Suporte de Vendas', value: 'Problemas com compras, pagamentos ou produtos', inline: true },
                { name: '🔧 Suporte Técnico', value: 'Problemas técnicos ou bugs', inline: true },
                { name: '❓ Dúvidas Gerais', value: 'Outras dúvidas ou informações', inline: true }
            )
            .setColor('#0099ff')
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_vendas')
                    .setLabel('Suporte de Vendas')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('💰'),
                new ButtonBuilder()
                    .setCustomId('ticket_tecnico')
                    .setLabel('Suporte Técnico')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🔧'),
                new ButtonBuilder()
                    .setCustomId('ticket_geral')
                    .setLabel('Dúvidas Gerais')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('❓')
            );

        await interaction.reply({ embeds: [embed], components: [buttons] });
    },

    async listTickets(interaction, database) {
        const tickets = await database.getAllTickets();

        if (tickets.length === 0) {
            return await interaction.reply({ 
                content: 'Nenhum ticket encontrado.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('🎫 Lista de Tickets')
            .setColor('#0099ff')
            .setTimestamp();

        for (const ticket of tickets.slice(0, 10)) { // Máximo 10 tickets
            const statusEmoji = {
                'open': '🟢',
                'closed': '🔴',
                'in_progress': '🟡'
            };

            const createdDate = new Date(ticket.created_at);

            embed.addFields({
                name: `${statusEmoji[ticket.status] || '❓'} Ticket #${ticket.id}`,
                value: `**Usuário:** <@${ticket.user_id}>\n**Categoria:** ${ticket.category}\n**Assunto:** ${ticket.subject}\n**Status:** ${ticket.status}\n**Criado:** ${createdDate.toLocaleDateString('pt-BR')}`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async closeTicket(interaction, database) {
        // Verificar se o comando foi usado em um canal de ticket
        const ticket = await database.getTicketByChannel(interaction.channel.id);
        
        if (!ticket) {
            return await interaction.reply({ 
                content: 'Este comando só pode ser usado em canais de ticket!', 
                ephemeral: true 
            });
        }

        if (ticket.status === 'closed') {
            return await interaction.reply({ 
                content: 'Este ticket já está fechado!', 
                ephemeral: true 
            });
        }

        // Atualizar status do ticket
        await database.updateTicket(ticket.id, { status: 'closed' });

        const embed = new EmbedBuilder()
            .setTitle('🔒 Ticket Fechado')
            .setDescription('Este ticket foi fechado por um moderador.')
            .addFields(
                { name: 'Ticket ID', value: ticket.id.toString(), inline: true },
                { name: 'Fechado por', value: `<@${interaction.user.id}>`, inline: true }
            )
            .setColor('#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Aguardar 5 segundos e deletar o canal
        setTimeout(async () => {
            try {
                await interaction.channel.delete();
            } catch (error) {
                console.error('Erro ao deletar canal de ticket:', error);
            }
        }, 5000);

        // Notificar o usuário por DM
        try {
            const user = await interaction.client.users.fetch(ticket.user_id);
            
            const dmEmbed = new EmbedBuilder()
                .setTitle('🔒 Ticket Fechado')
                .setDescription('Seu ticket de suporte foi fechado.')
                .addFields(
                    { name: 'Ticket ID', value: ticket.id.toString(), inline: true },
                    { name: 'Categoria', value: ticket.category, inline: true },
                    { name: 'Assunto', value: ticket.subject, inline: true }
                )
                .setColor('#ff0000')
                .setTimestamp();

            await user.send({ embeds: [dmEmbed] });
        } catch (dmError) {
            console.error('Erro ao enviar DM de fechamento:', dmError);
        }
    }
};

