const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('cupom')
        .setDescription('Gerenciar cupons de desconto')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('criar')
                .setDescription('Criar um novo cupom')
                .addStringOption(option =>
                    option.setName('codigo')
                        .setDescription('Código do cupom')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('tipo')
                        .setDescription('Tipo de desconto')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Porcentagem', value: 'percentage' },
                            { name: 'Valor Fixo', value: 'fixed' }
                        ))
                .addNumberOption(option =>
                    option.setName('valor')
                        .setDescription('Valor do desconto (% ou R$)')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('usos')
                        .setDescription('Número máximo de usos')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('expira')
                        .setDescription('Data de expiração (YYYY-MM-DD)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('listar')
                .setDescription('Listar todos os cupons'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('info')
                .setDescription('Informações de um cupom específico')
                .addStringOption(option =>
                    option.setName('codigo')
                        .setDescription('Código do cupom')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('desativar')
                .setDescription('Desativar um cupom')
                .addStringOption(option =>
                    option.setName('codigo')
                        .setDescription('Código do cupom')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('ativar')
                .setDescription('Ativar um cupom')
                .addStringOption(option =>
                    option.setName('codigo')
                        .setDescription('Código do cupom')
                        .setRequired(true))),
    
    async execute(interaction, database) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'criar':
                    await this.createCoupon(interaction, database);
                    break;
                case 'listar':
                    await this.listCoupons(interaction, database);
                    break;
                case 'info':
                    await this.couponInfo(interaction, database);
                    break;
                case 'desativar':
                    await this.deactivateCoupon(interaction, database);
                    break;
                case 'ativar':
                    await this.activateCoupon(interaction, database);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando cupom:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async createCoupon(interaction, database) {
        const codigo = interaction.options.getString('codigo').toUpperCase();
        const tipo = interaction.options.getString('tipo');
        const valor = interaction.options.getNumber('valor');
        const usos = interaction.options.getInteger('usos') || 1;
        const expira = interaction.options.getString('expira');

        // Validações
        if (tipo === 'percentage' && (valor <= 0 || valor > 100)) {
            return await interaction.reply({ 
                content: 'Para desconto em porcentagem, o valor deve estar entre 1 e 100!', 
                ephemeral: true 
            });
        }

        if (tipo === 'fixed' && valor <= 0) {
            return await interaction.reply({ 
                content: 'Para desconto fixo, o valor deve ser maior que 0!', 
                ephemeral: true 
            });
        }

        // Verificar se cupom já existe
        const existingCoupon = await database.getCoupon(codigo);
        if (existingCoupon) {
            return await interaction.reply({ 
                content: 'Já existe um cupom com este código!', 
                ephemeral: true 
            });
        }

        let expiresAt = null;
        if (expira) {
            expiresAt = new Date(expira + 'T23:59:59');
            if (isNaN(expiresAt.getTime())) {
                return await interaction.reply({ 
                    content: 'Data de expiração inválida! Use o formato YYYY-MM-DD', 
                    ephemeral: true 
                });
            }
        }

        const coupon = await database.createCoupon({
            code: codigo,
            type: tipo,
            value: valor,
            max_uses: usos,
            expires_at: expiresAt
        });

        const embed = new EmbedBuilder()
            .setTitle('🎫 Cupom Criado')
            .setDescription(`Cupom **${coupon.code}** foi criado com sucesso!`)
            .addFields(
                { name: 'Código', value: coupon.code, inline: true },
                { name: 'Tipo', value: tipo === 'percentage' ? 'Porcentagem' : 'Valor Fixo', inline: true },
                { name: 'Valor', value: tipo === 'percentage' ? `${valor}%` : `R$ ${valor.toFixed(2)}`, inline: true },
                { name: 'Usos Máximos', value: usos.toString(), inline: true },
                { name: 'Usos Restantes', value: usos.toString(), inline: true }
            )
            .setColor('#00ff00')
            .setTimestamp();

        if (expiresAt) {
            embed.addFields({ name: 'Expira em', value: expiresAt.toLocaleDateString('pt-BR'), inline: true });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async listCoupons(interaction, database) {
        const coupons = await database.getAllCoupons();

        if (coupons.length === 0) {
            return await interaction.reply({ 
                content: 'Nenhum cupom cadastrado.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('🎫 Lista de Cupons')
            .setColor('#0099ff')
            .setTimestamp();

        for (const coupon of coupons.slice(0, 10)) { // Máximo 10 cupons
            const statusEmoji = coupon.active ? '✅' : '❌';
            const typeText = coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`;
            
            let expiryText = 'Sem expiração';
            if (coupon.expires_at) {
                const expiryDate = new Date(coupon.expires_at);
                expiryText = expiryDate.toLocaleDateString('pt-BR');
            }

            embed.addFields({
                name: `${statusEmoji} ${coupon.code}`,
                value: `**Desconto:** ${typeText}\n**Usos:** ${coupon.uses_left}/${coupon.max_uses}\n**Expira:** ${expiryText}`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async couponInfo(interaction, database) {
        const codigo = interaction.options.getString('codigo').toUpperCase();

        const coupon = await database.getCoupon(codigo);
        if (!coupon) {
            return await interaction.reply({ 
                content: 'Cupom não encontrado!', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle(`🎫 Informações do Cupom: ${coupon.code}`)
            .addFields(
                { name: 'Código', value: coupon.code, inline: true },
                { name: 'Tipo', value: coupon.type === 'percentage' ? 'Porcentagem' : 'Valor Fixo', inline: true },
                { name: 'Valor', value: coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value.toFixed(2)}`, inline: true },
                { name: 'Status', value: coupon.active ? '✅ Ativo' : '❌ Inativo', inline: true },
                { name: 'Usos Restantes', value: `${coupon.uses_left}/${coupon.max_uses}`, inline: true }
            )
            .setColor(coupon.active ? '#00ff00' : '#ff0000')
            .setTimestamp();

        if (coupon.expires_at) {
            const expiryDate = new Date(coupon.expires_at);
            embed.addFields({ name: 'Data de Expiração', value: expiryDate.toLocaleDateString('pt-BR'), inline: true });
        }

        const createdDate = new Date(coupon.created_at);
        embed.addFields({ name: 'Criado em', value: createdDate.toLocaleDateString('pt-BR'), inline: true });

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async deactivateCoupon(interaction, database) {
        const codigo = interaction.options.getString('codigo').toUpperCase();

        const coupon = await database.getCoupon(codigo);
        if (!coupon) {
            return await interaction.reply({ 
                content: 'Cupom não encontrado!', 
                ephemeral: true 
            });
        }

        if (!coupon.active) {
            return await interaction.reply({ 
                content: 'Este cupom já está desativado!', 
                ephemeral: true 
            });
        }

        await database.updateCoupon(coupon.id, { active: false });

        const embed = new EmbedBuilder()
            .setTitle('❌ Cupom Desativado')
            .setDescription(`Cupom **${coupon.code}** foi desativado com sucesso!`)
            .setColor('#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async activateCoupon(interaction, database) {
        const codigo = interaction.options.getString('codigo').toUpperCase();

        const coupon = await database.get('SELECT * FROM coupons WHERE code = ?', [codigo]);
        if (!coupon) {
            return await interaction.reply({ 
                content: 'Cupom não encontrado!', 
                ephemeral: true 
            });
        }

        if (coupon.active) {
            return await interaction.reply({ 
                content: 'Este cupom já está ativo!', 
                ephemeral: true 
            });
        }

        await database.updateCoupon(coupon.id, { active: true });

        const embed = new EmbedBuilder()
            .setTitle('✅ Cupom Ativado')
            .setDescription(`Cupom **${coupon.code}** foi ativado com sucesso!`)
            .setColor('#00ff00')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

