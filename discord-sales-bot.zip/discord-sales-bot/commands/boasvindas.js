const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('boasvindas')
        .setDescription('Configurar mensagens de boas-vindas')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('testar')
                .setDescription('Testar mensagem de boas-vindas')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuário para testar (opcional)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('canal')
                .setDescription('Definir canal de boas-vindas')
                .addChannelOption(option =>
                    option.setName('canal')
                        .setDescription('Canal para mensagens de boas-vindas')
                        .setRequired(true))),
    
    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'testar':
                    await this.testWelcome(interaction);
                    break;
                case 'canal':
                    await this.setWelcomeChannel(interaction);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando boasvindas:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async testWelcome(interaction) {
        const user = interaction.options.getUser('usuario') || interaction.user;
        const member = await interaction.guild.members.fetch(user.id);

        // Simular evento de boas-vindas
        await this.sendWelcomeMessage(member, interaction.channel);

        await interaction.reply({ 
            content: `Mensagem de boas-vindas enviada para ${user}!`, 
            ephemeral: true 
        });
    },

    async setWelcomeChannel(interaction) {
        const channel = interaction.options.getChannel('canal');

        // Aqui você poderia salvar no banco de dados ou arquivo de configuração
        // Por simplicidade, vamos apenas confirmar
        
        const embed = new EmbedBuilder()
            .setTitle('✅ Canal de Boas-vindas Configurado')
            .setDescription(`Canal de boas-vindas definido como ${channel}`)
            .addFields(
                { name: 'Canal', value: channel.toString(), inline: true },
                { name: 'Configurado por', value: interaction.user.toString(), inline: true }
            )
            .setColor('#00ff00')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });

        // Nota: Para implementação completa, você salvaria isso no .env ou banco de dados
        console.log(`Canal de boas-vindas configurado: ${channel.id}`);
    },

    async sendWelcomeMessage(member, channel = null) {
        try {
            const welcomeChannel = channel || member.guild.channels.cache.get(process.env.WELCOME_CHANNEL_ID);
            
            if (!welcomeChannel) {
                console.log('Canal de boas-vindas não configurado');
                return;
            }

            const embed = new EmbedBuilder()
                .setTitle('🎉 Bem-vindo(a)!')
                .setDescription(`Olá ${member}, seja bem-vindo(a) ao **${member.guild.name}**!\n\n` +
                    `🔹 Leia as regras do servidor\n` +
                    `🔹 Clique no botão de verificação para ter acesso completo\n` +
                    `🔹 Confira nossa loja de produtos\n` +
                    `🔹 Use o sistema de suporte se precisar de ajuda`)
                .setColor('#00ff00')
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                .setFooter({ 
                    text: `Membro #${member.guild.memberCount}`, 
                    iconURL: member.guild.iconURL() 
                })
                .setTimestamp();

            // Adicionar botão de verificação se não estiver verificado
            const verifiedRole = member.guild.roles.cache.find(role => role.name === 'Verificado');
            const components = [];

            if (verifiedRole && !member.roles.cache.has(verifiedRole.id)) {
                const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
                
                const verifyButton = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('verify')
                            .setLabel('Verificar-se')
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('✅')
                    );
                
                components.push(verifyButton);
            }

            await welcomeChannel.send({ 
                content: `${member}`, 
                embeds: [embed], 
                components: components 
            });

            // Enviar DM de boas-vindas
            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle(`🎉 Bem-vindo(a) ao ${member.guild.name}!`)
                    .setDescription(`Olá ${member.user.username}!\n\n` +
                        `Obrigado por se juntar ao nosso servidor. Aqui estão algumas informações importantes:\n\n` +
                        `🔹 **Verificação**: Não esqueça de se verificar no canal de boas-vindas\n` +
                        `🔹 **Loja**: Confira nossos produtos usando o comando \`/loja\`\n` +
                        `🔹 **Suporte**: Use \`/suporte painel\` se precisar de ajuda\n` +
                        `🔹 **Regras**: Leia e siga as regras do servidor\n\n` +
                        `Esperamos que você tenha uma ótima experiência conosco!`)
                    .setColor('#00ff00')
                    .setThumbnail(member.guild.iconURL())
                    .setTimestamp();

                await member.send({ embeds: [dmEmbed] });
            } catch (dmError) {
                console.log('Não foi possível enviar DM de boas-vindas:', dmError.message);
            }

        } catch (error) {
            console.error('Erro ao enviar mensagem de boas-vindas:', error);
        }
    }
};

