const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verificacao')
        .setDescription('Sistema de verificação de usuários')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('painel')
                .setDescription('Criar painel de verificação'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('verificar')
                .setDescription('Verificar um usuário manualmente')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuário para verificar')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('desverificar')
                .setDescription('Remover verificação de um usuário')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuário para desverificar')
                        .setRequired(true))),
    
    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'painel':
                    await this.createVerificationPanel(interaction);
                    break;
                case 'verificar':
                    await this.verifyUser(interaction);
                    break;
                case 'desverificar':
                    await this.unverifyUser(interaction);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando verificacao:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async createVerificationPanel(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('✅ Verificação de Usuário')
            .setDescription('Bem-vindo ao nosso servidor!\n\nPara ter acesso completo ao servidor e poder visualizar todos os canais, clique no botão abaixo para se verificar.')
            .addFields(
                { name: '📋 Regras', value: 'Ao se verificar, você concorda em seguir as regras do servidor.', inline: false },
                { name: '🎯 Benefícios', value: 'Acesso a todos os canais, participação em eventos e muito mais!', inline: false }
            )
            .setColor('#00ff00')
            .setTimestamp();

        const verifyButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('verify')
                    .setLabel('Verificar-se')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅')
            );

        await interaction.reply({ embeds: [embed], components: [verifyButton] });
    },

    async verifyUser(interaction) {
        const user = interaction.options.getUser('usuario');
        const member = await interaction.guild.members.fetch(user.id);

        if (!member) {
            return await interaction.reply({ 
                content: 'Usuário não encontrado no servidor!', 
                ephemeral: true 
            });
        }

        // Buscar ou criar cargo de verificado
        let verifiedRole = interaction.guild.roles.cache.find(role => role.name === 'Verificado');
        
        if (!verifiedRole) {
            try {
                verifiedRole = await interaction.guild.roles.create({
                    name: 'Verificado',
                    color: '#00ff00',
                    reason: 'Cargo criado automaticamente pelo sistema de verificação'
                });
            } catch (error) {
                console.error('Erro ao criar cargo:', error);
                return await interaction.reply({ 
                    content: 'Erro ao criar cargo de verificado!', 
                    ephemeral: true 
                });
            }
        }

        if (member.roles.cache.has(verifiedRole.id)) {
            return await interaction.reply({ 
                content: 'Este usuário já está verificado!', 
                ephemeral: true 
            });
        }

        try {
            await member.roles.add(verifiedRole);

            const embed = new EmbedBuilder()
                .setTitle('✅ Usuário Verificado')
                .setDescription(`${user} foi verificado manualmente por ${interaction.user}`)
                .setColor('#00ff00')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            // Notificar o usuário por DM
            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle('✅ Verificação Aprovada')
                    .setDescription(`Você foi verificado manualmente no servidor **${interaction.guild.name}**!\n\nAgora você tem acesso completo ao servidor.`)
                    .setColor('#00ff00')
                    .setTimestamp();

                await user.send({ embeds: [dmEmbed] });
            } catch (dmError) {
                console.error('Erro ao enviar DM:', dmError);
            }

        } catch (error) {
            console.error('Erro ao adicionar cargo:', error);
            await interaction.reply({ 
                content: 'Erro ao verificar usuário!', 
                ephemeral: true 
            });
        }
    },

    async unverifyUser(interaction) {
        const user = interaction.options.getUser('usuario');
        const member = await interaction.guild.members.fetch(user.id);

        if (!member) {
            return await interaction.reply({ 
                content: 'Usuário não encontrado no servidor!', 
                ephemeral: true 
            });
        }

        const verifiedRole = interaction.guild.roles.cache.find(role => role.name === 'Verificado');
        
        if (!verifiedRole) {
            return await interaction.reply({ 
                content: 'Cargo de verificado não encontrado!', 
                ephemeral: true 
            });
        }

        if (!member.roles.cache.has(verifiedRole.id)) {
            return await interaction.reply({ 
                content: 'Este usuário não está verificado!', 
                ephemeral: true 
            });
        }

        try {
            await member.roles.remove(verifiedRole);

            const embed = new EmbedBuilder()
                .setTitle('❌ Verificação Removida')
                .setDescription(`A verificação de ${user} foi removida por ${interaction.user}`)
                .setColor('#ff0000')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            // Notificar o usuário por DM
            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle('❌ Verificação Removida')
                    .setDescription(`Sua verificação foi removida no servidor **${interaction.guild.name}**.\n\nSe você acredita que isso foi um erro, entre em contato com a administração.`)
                    .setColor('#ff0000')
                    .setTimestamp();

                await user.send({ embeds: [dmEmbed] });
            } catch (dmError) {
                console.error('Erro ao enviar DM:', dmError);
            }

        } catch (error) {
            console.error('Erro ao remover cargo:', error);
            await interaction.reply({ 
                content: 'Erro ao remover verificação!', 
                ephemeral: true 
            });
        }
    }
};

