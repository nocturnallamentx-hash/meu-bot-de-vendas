const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('produto')
        .setDescription('Gerenciar produtos da loja')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('criar')
                .setDescription('Criar um novo produto')
                .addStringOption(option =>
                    option.setName('nome')
                        .setDescription('Nome do produto')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('descricao')
                        .setDescription('Descrição do produto')
                        .setRequired(true))
                .addNumberOption(option =>
                    option.setName('preco')
                        .setDescription('Preço do produto')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('estoque')
                        .setDescription('Quantidade em estoque')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('categoria')
                        .setDescription('Categoria do produto')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('imagem')
                        .setDescription('URL da imagem do produto')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('conteudo')
                        .setDescription('Conteúdo do produto (para produtos digitais)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('listar')
                .setDescription('Listar todos os produtos'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('editar')
                .setDescription('Editar um produto existente')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('ID do produto')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('nome')
                        .setDescription('Novo nome do produto')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('descricao')
                        .setDescription('Nova descrição do produto')
                        .setRequired(false))
                .addNumberOption(option =>
                    option.setName('preco')
                        .setDescription('Novo preço do produto')
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('estoque')
                        .setDescription('Nova quantidade em estoque')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('deletar')
                .setDescription('Deletar um produto')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('ID do produto')
                        .setRequired(true))),
    
    async execute(interaction, database) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'criar':
                    await this.createProduct(interaction, database);
                    break;
                case 'listar':
                    await this.listProducts(interaction, database);
                    break;
                case 'editar':
                    await this.editProduct(interaction, database);
                    break;
                case 'deletar':
                    await this.deleteProduct(interaction, database);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando produto:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async createProduct(interaction, database) {
        const nome = interaction.options.getString('nome');
        const descricao = interaction.options.getString('descricao');
        const preco = interaction.options.getNumber('preco');
        const estoque = interaction.options.getInteger('estoque');
        const categoria = interaction.options.getString('categoria') || 'Geral';
        const imagem = interaction.options.getString('imagem') || null;
        const conteudo = interaction.options.getString('conteudo') || null;

        const product = await database.createProduct({
            name: nome,
            description: descricao,
            price: preco,
            stock: estoque,
            category: categoria,
            image_url: imagem,
            content: conteudo
        });

        const embed = new EmbedBuilder()
            .setTitle('✅ Produto Criado')
            .setDescription(`**${product.name}** foi criado com sucesso!`)
            .addFields(
                { name: 'ID', value: product.id.toString(), inline: true },
                { name: 'Preço', value: `R$ ${product.price.toFixed(2)}`, inline: true },
                { name: 'Estoque', value: product.stock.toString(), inline: true }
            )
            .setColor('#00ff00')
            .setTimestamp();

        if (product.image_url) {
            embed.setThumbnail(product.image_url);
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async listProducts(interaction, database) {
        const products = await database.getAllProducts();

        if (products.length === 0) {
            return await interaction.reply({ 
                content: 'Nenhum produto cadastrado.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('📦 Lista de Produtos')
            .setColor('#0099ff')
            .setTimestamp();

        for (const product of products.slice(0, 10)) { // Máximo 10 produtos
            embed.addFields({
                name: `ID: ${product.id} - ${product.name}`,
                value: `**Preço:** R$ ${product.price.toFixed(2)}\n**Estoque:** ${product.stock}\n**Categoria:** ${product.category}`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async editProduct(interaction, database) {
        const id = interaction.options.getInteger('id');
        const nome = interaction.options.getString('nome');
        const descricao = interaction.options.getString('descricao');
        const preco = interaction.options.getNumber('preco');
        const estoque = interaction.options.getInteger('estoque');

        const product = await database.getProduct(id);
        if (!product) {
            return await interaction.reply({ 
                content: 'Produto não encontrado!', 
                ephemeral: true 
            });
        }

        const updateData = {};
        if (nome) updateData.name = nome;
        if (descricao) updateData.description = descricao;
        if (preco !== null) updateData.price = preco;
        if (estoque !== null) updateData.stock = estoque;

        const updatedProduct = await database.updateProduct(id, updateData);

        const embed = new EmbedBuilder()
            .setTitle('✅ Produto Atualizado')
            .setDescription(`**${updatedProduct.name}** foi atualizado com sucesso!`)
            .addFields(
                { name: 'ID', value: updatedProduct.id.toString(), inline: true },
                { name: 'Preço', value: `R$ ${updatedProduct.price.toFixed(2)}`, inline: true },
                { name: 'Estoque', value: updatedProduct.stock.toString(), inline: true }
            )
            .setColor('#00ff00')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async deleteProduct(interaction, database) {
        const id = interaction.options.getInteger('id');

        const product = await database.getProduct(id);
        if (!product) {
            return await interaction.reply({ 
                content: 'Produto não encontrado!', 
                ephemeral: true 
            });
        }

        await database.deleteProduct(id);

        const embed = new EmbedBuilder()
            .setTitle('🗑️ Produto Deletado')
            .setDescription(`**${product.name}** foi deletado com sucesso!`)
            .setColor('#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

