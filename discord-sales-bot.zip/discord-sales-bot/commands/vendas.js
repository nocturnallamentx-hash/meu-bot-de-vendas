const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('vendas')
        .setDescription('Gerenciar vendas e pagamentos')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('listar')
                .setDescription('Listar todas as vendas'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('aprovar')
                .setDescription('Aprovar uma venda manualmente')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('ID da venda')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('rejeitar')
                .setDescription('Rejeitar uma venda')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('ID da venda')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('status')
                .setDescription('Verificar status de um pagamento')
                .addStringOption(option =>
                    option.setName('payment_id')
                        .setDescription('ID do pagamento no Mercado Pago')
                        .setRequired(true))),
    
    async execute(interaction, database, mercadoPago) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'listar':
                    await this.listSales(interaction, database);
                    break;
                case 'aprovar':
                    await this.approveSale(interaction, database, mercadoPago);
                    break;
                case 'rejeitar':
                    await this.rejectSale(interaction, database);
                    break;
                case 'status':
                    await this.checkPaymentStatus(interaction, mercadoPago);
                    break;
            }
        } catch (error) {
            console.error('Erro no comando vendas:', error);
            await interaction.reply({ 
                content: 'Erro ao executar comando!', 
                ephemeral: true 
            });
        }
    },

    async listSales(interaction, database) {
        const sales = await database.getAllSales();

        if (sales.length === 0) {
            return await interaction.reply({ 
                content: 'Nenhuma venda encontrada.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('💰 Lista de Vendas')
            .setColor('#0099ff')
            .setTimestamp();

        for (const sale of sales.slice(0, 10)) { // Máximo 10 vendas
            const statusEmoji = {
                'pending': '⏳',
                'approved': '✅',
                'rejected': '❌',
                'cancelled': '🚫'
            };

            embed.addFields({
                name: `${statusEmoji[sale.status] || '❓'} Venda #${sale.id}`,
                value: `**Produto:** ${sale.product_name || 'N/A'}\n**Valor:** R$ ${sale.amount.toFixed(2)}\n**Status:** ${sale.status}\n**Cliente:** <@${sale.user_id}>`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async approveSale(interaction, database, mercadoPago) {
        const saleId = interaction.options.getInteger('id');

        const sale = await database.getSale(saleId);
        if (!sale) {
            return await interaction.reply({ 
                content: 'Venda não encontrada!', 
                ephemeral: true 
            });
        }

        if (sale.status === 'approved') {
            return await interaction.reply({ 
                content: 'Esta venda já foi aprovada!', 
                ephemeral: true 
            });
        }

        // Atualizar status da venda
        await database.updateSale(saleId, { status: 'approved' });

        // Diminuir estoque
        await database.decreaseStock(sale.product_id, 1);

        // Buscar produto
        const product = await database.getProduct(sale.product_id);

        // Usar cupom se aplicável
        if (sale.coupon_id) {
            const coupon = await database.get('SELECT * FROM coupons WHERE id = ?', [sale.coupon_id]);
            if (coupon) {
                await database.useCoupon(coupon.code);
            }
        }

        // Atualizar estatísticas do usuário
        await database.createOrUpdateUser(sale.user_id, { email: sale.email });
        await database.incrementUserPurchases(sale.user_id, sale.amount);

        // Enviar produto por DM
        try {
            const user = await interaction.client.users.fetch(sale.user_id);
            
            const dmEmbed = new EmbedBuilder()
                .setTitle('✅ Pagamento Aprovado!')
                .setDescription(`Seu pagamento foi aprovado manualmente e o produto foi entregue.`)
                .addFields(
                    { name: 'Produto', value: product.name, inline: true },
                    { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true },
                    { name: 'ID da Compra', value: sale.id.toString(), inline: true }
                )
                .setColor('#00ff00')
                .setTimestamp();

            if (product.content) {
                dmEmbed.addFields({ name: 'Conteúdo', value: product.content, inline: false });
            }

            await user.send({ embeds: [dmEmbed] });

        } catch (dmError) {
            console.error('Erro ao enviar DM:', dmError);
        }

        const embed = new EmbedBuilder()
            .setTitle('✅ Venda Aprovada')
            .setDescription(`Venda #${saleId} foi aprovada manualmente.`)
            .addFields(
                { name: 'Produto', value: product.name, inline: true },
                { name: 'Cliente', value: `<@${sale.user_id}>`, inline: true },
                { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true }
            )
            .setColor('#00ff00')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async rejectSale(interaction, database) {
        const saleId = interaction.options.getInteger('id');

        const sale = await database.getSale(saleId);
        if (!sale) {
            return await interaction.reply({ 
                content: 'Venda não encontrada!', 
                ephemeral: true 
            });
        }

        if (sale.status === 'rejected') {
            return await interaction.reply({ 
                content: 'Esta venda já foi rejeitada!', 
                ephemeral: true 
            });
        }

        // Atualizar status da venda
        await database.updateSale(saleId, { status: 'rejected' });

        // Buscar produto
        const product = await database.getProduct(sale.product_id);

        // Notificar cliente
        try {
            const user = await interaction.client.users.fetch(sale.user_id);
            
            const dmEmbed = new EmbedBuilder()
                .setTitle('❌ Pagamento Rejeitado')
                .setDescription(`Seu pagamento foi rejeitado. Entre em contato com o suporte se necessário.`)
                .addFields(
                    { name: 'Produto', value: product.name, inline: true },
                    { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true },
                    { name: 'ID da Compra', value: sale.id.toString(), inline: true }
                )
                .setColor('#ff0000')
                .setTimestamp();

            await user.send({ embeds: [dmEmbed] });

        } catch (dmError) {
            console.error('Erro ao enviar DM:', dmError);
        }

        const embed = new EmbedBuilder()
            .setTitle('❌ Venda Rejeitada')
            .setDescription(`Venda #${saleId} foi rejeitada.`)
            .addFields(
                { name: 'Produto', value: product.name, inline: true },
                { name: 'Cliente', value: `<@${sale.user_id}>`, inline: true },
                { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true }
            )
            .setColor('#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async checkPaymentStatus(interaction, mercadoPago) {
        const paymentId = interaction.options.getString('payment_id');

        try {
            const status = await mercadoPago.checkPaymentStatus(paymentId);

            const statusEmoji = {
                'pending': '⏳',
                'approved': '✅',
                'rejected': '❌',
                'cancelled': '🚫',
                'in_process': '🔄'
            };

            const embed = new EmbedBuilder()
                .setTitle('💳 Status do Pagamento')
                .addFields(
                    { name: 'ID do Pagamento', value: paymentId, inline: true },
                    { name: 'Status', value: `${statusEmoji[status.status] || '❓'} ${status.status}`, inline: true },
                    { name: 'Valor', value: `R$ ${status.amount.toFixed(2)}`, inline: true }
                )
                .setColor(status.status === 'approved' ? '#00ff00' : '#ff9900')
                .setTimestamp();

            if (status.date_approved) {
                embed.addFields({ name: 'Data de Aprovação', value: status.date_approved, inline: true });
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            await interaction.reply({ 
                content: 'Erro ao verificar status do pagamento!', 
                ephemeral: true 
            });
        }
    }
};

