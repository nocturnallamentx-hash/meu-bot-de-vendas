const { MercadoPagoConfig, Payment, Preference } = require('mercadopago');
const axios = require('axios');

class MercadoPagoService {
    constructor() {
        this.client = new MercadoPagoConfig({
            accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN,
        });
        this.payment = new Payment(this.client);
        this.preference = new Preference(this.client);
    }

    async createPayment(data) {
        try {
            const { productId, userId, email, amount, description, couponId } = data;

            // Criar preferência de pagamento
            const preferenceData = {
                items: [
                    {
                        id: productId.toString(),
                        title: description,
                        quantity: 1,
                        unit_price: amount,
                        currency_id: 'BRL'
                    }
                ],
                payer: {
                    email: email
                },
                payment_methods: {
                    excluded_payment_types: [],
                    installments: 1
                },
                notification_url: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/webhook/mercadopago`,
                external_reference: `${userId}_${productId}_${Date.now()}`,
                auto_return: 'approved',
                back_urls: {
                    success: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/success`,
                    failure: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/failure`,
                    pending: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/pending`
                }
            };

            const preference = await this.preference.create({ body: preferenceData });

            // Criar pagamento PIX
            const pixPayment = await this.payment.create({
                body: {
                    transaction_amount: amount,
                    description: description,
                    payment_method_id: 'pix',
                    payer: {
                        email: email
                    },
                    external_reference: `${userId}_${productId}_${Date.now()}`
                }
            });

            return {
                id: preference.id,
                payment_url: preference.init_point,
                pix_code: pixPayment.point_of_interaction?.transaction_data?.qr_code || 'PIX não disponível',
                pix_qr_code: pixPayment.point_of_interaction?.transaction_data?.qr_code_base64 || null,
                payment_id: pixPayment.id
            };

        } catch (error) {
            console.error('Erro ao criar pagamento:', error);
            throw new Error('Erro ao processar pagamento');
        }
    }

    async createPixPayment(data) {
        try {
            const { amount, description, email, externalReference } = data;

            const paymentData = {
                transaction_amount: amount,
                description: description,
                payment_method_id: 'pix',
                payer: {
                    email: email
                },
                external_reference: externalReference,
                notification_url: `${process.env.WEBHOOK_URL || 'https://your-domain.com'}/webhook/mercadopago`
            };

            const payment = await this.payment.create({ body: paymentData });

            return {
                id: payment.id,
                status: payment.status,
                qr_code: payment.point_of_interaction?.transaction_data?.qr_code,
                qr_code_base64: payment.point_of_interaction?.transaction_data?.qr_code_base64,
                ticket_url: payment.point_of_interaction?.transaction_data?.ticket_url
            };

        } catch (error) {
            console.error('Erro ao criar pagamento PIX:', error);
            throw new Error('Erro ao criar pagamento PIX');
        }
    }

    async getPayment(paymentId) {
        try {
            const payment = await this.payment.get({ id: paymentId });
            return payment;
        } catch (error) {
            console.error('Erro ao buscar pagamento:', error);
            throw new Error('Erro ao buscar pagamento');
        }
    }

    async handleWebhook(data, discordClient) {
        try {
            console.log('Webhook recebido:', data);

            if (data.type === 'payment') {
                const paymentId = data.data.id;
                const payment = await this.getPayment(paymentId);

                if (payment.status === 'approved') {
                    await this.processApprovedPayment(payment, discordClient);
                }
            }

        } catch (error) {
            console.error('Erro ao processar webhook:', error);
        }
    }

    async processApprovedPayment(payment, discordClient) {
        try {
            const Database = require('../database/database');
            const database = new Database();
            await database.init();

            // Buscar venda pelo payment_id
            const sale = await database.getSaleByPaymentId(payment.id);
            if (!sale) {
                console.log('Venda não encontrada para o pagamento:', payment.id);
                return;
            }

            // Atualizar status da venda
            await database.updateSale(sale.id, { status: 'approved' });

            // Diminuir estoque
            await database.decreaseStock(sale.product_id, 1);

            // Buscar produto
            const product = await database.getProduct(sale.product_id);

            // Usar cupom se aplicável
            if (sale.coupon_id) {
                const coupon = await database.get('SELECT * FROM coupons WHERE id = ?', [sale.coupon_id]);
                if (coupon) {
                    await database.useCoupon(coupon.code);
                }
            }

            // Atualizar estatísticas do usuário
            await database.createOrUpdateUser(sale.user_id, { email: sale.email });
            await database.incrementUserPurchases(sale.user_id, sale.amount);

            // Enviar produto por DM
            try {
                const user = await discordClient.users.fetch(sale.user_id);
                
                const { EmbedBuilder } = require('discord.js');
                const embed = new EmbedBuilder()
                    .setTitle('✅ Pagamento Aprovado!')
                    .setDescription(`Seu pagamento foi aprovado e o produto foi entregue.`)
                    .addFields(
                        { name: 'Produto', value: product.name, inline: true },
                        { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true },
                        { name: 'ID da Compra', value: sale.id.toString(), inline: true }
                    )
                    .setColor('#00ff00')
                    .setTimestamp();

                if (product.content) {
                    embed.addFields({ name: 'Conteúdo', value: product.content, inline: false });
                }

                await user.send({ embeds: [embed] });

                // Log no canal de logs se configurado
                const logsChannelId = process.env.LOGS_CHANNEL_ID;
                if (logsChannelId) {
                    const logsChannel = discordClient.channels.cache.get(logsChannelId);
                    if (logsChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setTitle('💰 Nova Venda')
                            .setDescription(`Venda aprovada automaticamente`)
                            .addFields(
                                { name: 'Cliente', value: `<@${sale.user_id}>`, inline: true },
                                { name: 'Produto', value: product.name, inline: true },
                                { name: 'Valor', value: `R$ ${sale.amount.toFixed(2)}`, inline: true }
                            )
                            .setColor('#00ff00')
                            .setTimestamp();

                        await logsChannel.send({ embeds: [logEmbed] });
                    }
                }

            } catch (dmError) {
                console.error('Erro ao enviar DM:', dmError);
            }

            database.close();

        } catch (error) {
            console.error('Erro ao processar pagamento aprovado:', error);
        }
    }

    async checkPaymentStatus(paymentId) {
        try {
            const payment = await this.getPayment(paymentId);
            return {
                status: payment.status,
                status_detail: payment.status_detail,
                amount: payment.transaction_amount,
                date_approved: payment.date_approved
            };
        } catch (error) {
            console.error('Erro ao verificar status do pagamento:', error);
            throw new Error('Erro ao verificar pagamento');
        }
    }

    async refundPayment(paymentId, amount = null) {
        try {
            const refundData = {
                payment_id: paymentId
            };

            if (amount) {
                refundData.amount = amount;
            }

            const response = await axios.post(
                `https://api.mercadopago.com/v1/payments/${paymentId}/refunds`,
                refundData,
                {
                    headers: {
                        'Authorization': `Bearer ${process.env.MERCADO_PAGO_ACCESS_TOKEN}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            return response.data;

        } catch (error) {
            console.error('Erro ao estornar pagamento:', error);
            throw new Error('Erro ao processar estorno');
        }
    }
}

module.exports = MercadoPagoService;

