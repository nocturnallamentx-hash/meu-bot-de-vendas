const sqlite3 = require('sqlite3').verbose();
const path = require('path');

class Database {
    constructor() {
        this.dbPath = process.env.DATABASE_PATH || './database.sqlite';
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            this.db = new sqlite3.Database(this.dbPath, (err) => {
                if (err) {
                    reject(err);
                } else {
                    console.log('Conectado ao banco de dados SQLite');
                    this.createTables().then(resolve).catch(reject);
                }
            });
        });
    }

    async createTables() {
        const tables = [
            `CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                stock INTEGER DEFAULT 0,
                category TEXT,
                image_url TEXT,
                content TEXT,
                active BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            `CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                product_id INTEGER,
                amount REAL NOT NULL,
                payment_id TEXT,
                status TEXT DEFAULT 'pending',
                email TEXT,
                coupon_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products (id),
                FOREIGN KEY (coupon_id) REFERENCES coupons (id)
            )`,
            `CREATE TABLE IF NOT EXISTS coupons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                type TEXT NOT NULL, -- 'percentage' or 'fixed'
                value REAL NOT NULL,
                max_uses INTEGER DEFAULT 1,
                uses_left INTEGER DEFAULT 1,
                active BOOLEAN DEFAULT 1,
                expires_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            `CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                channel_id TEXT,
                category TEXT,
                subject TEXT,
                description TEXT,
                status TEXT DEFAULT 'open',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            `CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT,
                purchases INTEGER DEFAULT 0,
                total_spent REAL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`
        ];

        for (const table of tables) {
            await this.run(table);
        }
    }

    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: this.lastID, changes: this.changes });
                }
            });
        });
    }

    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }

    // Métodos para produtos
    async createProduct(data) {
        const { name, description, price, stock, category, image_url, content } = data;
        const result = await this.run(
            'INSERT INTO products (name, description, price, stock, category, image_url, content) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [name, description, price, stock, category, image_url, content]
        );
        return this.getProduct(result.id);
    }

    async getProduct(id) {
        return this.get('SELECT * FROM products WHERE id = ?', [id]);
    }

    async getAllProducts() {
        return this.all('SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC');
    }

    async updateProduct(id, data) {
        const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
        const values = Object.values(data);
        values.push(id);
        
        await this.run(`UPDATE products SET ${fields} WHERE id = ?`, values);
        return this.getProduct(id);
    }

    async deleteProduct(id) {
        return this.run('UPDATE products SET active = 0 WHERE id = ?', [id]);
    }

    async decreaseStock(productId, quantity = 1) {
        return this.run('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [quantity, productId, quantity]);
    }

    // Métodos para vendas
    async createSale(data) {
        const { user_id, product_id, amount, payment_id, status, email, coupon_id } = data;
        const result = await this.run(
            'INSERT INTO sales (user_id, product_id, amount, payment_id, status, email, coupon_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [user_id, product_id, amount, payment_id, status, email, coupon_id]
        );
        return this.getSale(result.id);
    }

    async getSale(id) {
        return this.get('SELECT * FROM sales WHERE id = ?', [id]);
    }

    async getSaleByPaymentId(paymentId) {
        return this.get('SELECT * FROM sales WHERE payment_id = ?', [paymentId]);
    }

    async getAllSales() {
        return this.all(`
            SELECT s.*, p.name as product_name, u.email as user_email 
            FROM sales s 
            LEFT JOIN products p ON s.product_id = p.id 
            LEFT JOIN users u ON s.user_id = u.id 
            ORDER BY s.created_at DESC
        `);
    }

    async updateSale(id, data) {
        const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
        const values = Object.values(data);
        values.push(id);
        
        await this.run(`UPDATE sales SET ${fields} WHERE id = ?`, values);
        return this.getSale(id);
    }

    // Métodos para cupons
    async createCoupon(data) {
        const { code, type, value, max_uses, expires_at } = data;
        const result = await this.run(
            'INSERT INTO coupons (code, type, value, max_uses, uses_left, expires_at) VALUES (?, ?, ?, ?, ?, ?)',
            [code, type, value, max_uses, max_uses, expires_at]
        );
        return this.getCoupon(code);
    }

    async getCoupon(code) {
        return this.get('SELECT * FROM coupons WHERE code = ? AND active = 1', [code]);
    }

    async getAllCoupons() {
        return this.all('SELECT * FROM coupons ORDER BY created_at DESC');
    }

    async useCoupon(code) {
        return this.run('UPDATE coupons SET uses_left = uses_left - 1 WHERE code = ? AND uses_left > 0', [code]);
    }

    async updateCoupon(id, data) {
        const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
        const values = Object.values(data);
        values.push(id);
        
        await this.run(`UPDATE coupons SET ${fields} WHERE id = ?`, values);
        return this.get('SELECT * FROM coupons WHERE id = ?', [id]);
    }

    // Métodos para tickets
    async createTicket(data) {
        const { user_id, channel_id, category, subject, description } = data;
        const result = await this.run(
            'INSERT INTO tickets (user_id, channel_id, category, subject, description) VALUES (?, ?, ?, ?, ?)',
            [user_id, channel_id, category, subject, description]
        );
        return this.getTicket(result.id);
    }

    async getTicket(id) {
        return this.get('SELECT * FROM tickets WHERE id = ?', [id]);
    }

    async getTicketByChannel(channelId) {
        return this.get('SELECT * FROM tickets WHERE channel_id = ?', [channelId]);
    }

    async getAllTickets() {
        return this.all('SELECT * FROM tickets ORDER BY created_at DESC');
    }

    async updateTicket(id, data) {
        const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
        const values = Object.values(data);
        values.push(id);
        
        await this.run(`UPDATE tickets SET ${fields} WHERE id = ?`, values);
        return this.getTicket(id);
    }

    // Métodos para usuários
    async createOrUpdateUser(userId, data = {}) {
        const existingUser = await this.get('SELECT * FROM users WHERE id = ?', [userId]);
        
        if (existingUser) {
            const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
            const values = Object.values(data);
            values.push(userId);
            
            await this.run(`UPDATE users SET ${fields} WHERE id = ?`, values);
        } else {
            const { email = null } = data;
            await this.run('INSERT INTO users (id, email) VALUES (?, ?)', [userId, email]);
        }
        
        return this.get('SELECT * FROM users WHERE id = ?', [userId]);
    }

    async getUser(userId) {
        return this.get('SELECT * FROM users WHERE id = ?', [userId]);
    }

    async incrementUserPurchases(userId, amount) {
        await this.run(
            'UPDATE users SET purchases = purchases + 1, total_spent = total_spent + ? WHERE id = ?',
            [amount, userId]
        );
    }

    close() {
        if (this.db) {
            this.db.close();
        }
    }
}

module.exports = Database;

