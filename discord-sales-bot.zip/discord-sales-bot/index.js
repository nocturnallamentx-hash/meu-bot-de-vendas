require('dotenv').config();
const { Client, GatewayIntentBits, Collection, REST, Routes, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits } = require('discord.js');
const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const Database = require('./database/database');
const MercadoPagoService = require('./services/mercadopago');

class SalesBot {
    constructor() {
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.DirectMessages
            ]
        });
        
        this.commands = new Collection();
        this.database = new Database();
        this.mercadoPago = new MercadoPagoService();
        this.app = express();
        
        this.setupExpress();
        this.loadCommands();
        this.setupEvents();
    }

    setupExpress() {
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.static('public'));
        
        // Webhook do Mercado Pago
        this.app.post('/webhook/mercadopago', async (req, res) => {
            try {
                await this.mercadoPago.handleWebhook(req.body, this.client);
                res.status(200).send('OK');
            } catch (error) {
                console.error('Erro no webhook:', error);
                res.status(500).send('Erro interno');
            }
        });

        // API para painel administrativo
        this.app.get('/api/products', async (req, res) => {
            try {
                const products = await this.database.getAllProducts();
                res.json(products);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.post('/api/products', async (req, res) => {
            try {
                const product = await this.database.createProduct(req.body);
                res.json(product);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.get('/api/sales', async (req, res) => {
            try {
                const sales = await this.database.getAllSales();
                res.json(sales);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.get('/api/coupons', async (req, res) => {
            try {
                const coupons = await this.database.getAllCoupons();
                res.json(coupons);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });

        this.app.post('/api/coupons', async (req, res) => {
            try {
                const coupon = await this.database.createCoupon(req.body);
                res.json(coupon);
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
    }

    async loadCommands() {
        const commandsPath = path.join(__dirname, 'commands');
        if (!await fs.pathExists(commandsPath)) {
            await fs.ensureDir(commandsPath);
        }

        const commandFiles = await fs.readdir(commandsPath);
        const jsFiles = commandFiles.filter(file => file.endsWith('.js'));

        for (const file of jsFiles) {
            const filePath = path.join(commandsPath, file);
            const command = require(filePath);
            if ('data' in command && 'execute' in command) {
                this.commands.set(command.data.name, command);
            }
        }
    }

    setupEvents() {
        this.client.once('ready', async () => {
            console.log(`Bot logado como ${this.client.user.tag}`);
            await this.database.init();
            await this.registerCommands();
            
            // Iniciar servidor Express
            this.app.listen(process.env.PORT || 3000, process.env.HOST || '0.0.0.0', () => {
                console.log(`Servidor rodando na porta ${process.env.PORT || 3000}`);
            });
        });

        this.client.on('guildMemberAdd', async (member) => {
            await this.handleWelcome(member);
        });

        this.client.on('interactionCreate', async (interaction) => {
            if (interaction.isChatInputCommand()) {
                await this.handleCommand(interaction);
            } else if (interaction.isButton()) {
                await this.handleButton(interaction);
            } else if (interaction.isModalSubmit()) {
                await this.handleModal(interaction);
            }
        });
    }

    async registerCommands() {
        const commands = [];
        this.commands.forEach(command => {
            commands.push(command.data.toJSON());
        });

        const rest = new REST().setToken(process.env.DISCORD_TOKEN);

        try {
            console.log('Registrando comandos slash...');
            await rest.put(
                Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
                { body: commands }
            );
            console.log('Comandos registrados com sucesso!');
        } catch (error) {
            console.error('Erro ao registrar comandos:', error);
        }
    }

    async handleCommand(interaction) {
        const command = this.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, this.database, this.mercadoPago);
        } catch (error) {
            console.error('Erro ao executar comando:', error);
            const reply = { content: 'Houve um erro ao executar este comando!', ephemeral: true };
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(reply);
            } else {
                await interaction.reply(reply);
            }
        }
    }

    async handleButton(interaction) {
        const [action, ...params] = interaction.customId.split('_');

        switch (action) {
            case 'buy':
                await this.handlePurchase(interaction, params[0]);
                break;
            case 'ticket':
                await this.handleTicketCreation(interaction, params[0]);
                break;
            case 'verify':
                await this.handleVerification(interaction);
                break;
            case 'close':
                if (params[0] === 'ticket') {
                    await this.handleTicketClose(interaction);
                }
                break;
        }
    }

    async handleModal(interaction) {
        const [action, ...params] = interaction.customId.split('_');

        switch (action) {
            case 'purchase':
                await this.processPurchaseModal(interaction, params[0]);
                break;
            case 'ticket':
                await this.processTicketModal(interaction, params[0]);
                break;
        }
    }

    async handlePurchase(interaction, productId) {
        try {
            const product = await this.database.getProduct(productId);
            if (!product) {
                return await interaction.reply({ content: 'Produto não encontrado!', ephemeral: true });
            }

            if (product.stock <= 0) {
                return await interaction.reply({ content: 'Produto fora de estoque!', ephemeral: true });
            }

            const modal = new ModalBuilder()
                .setCustomId(`purchase_${productId}`)
                .setTitle(`Comprar: ${product.name}`);

            const emailInput = new TextInputBuilder()
                .setCustomId('email')
                .setLabel('Seu email')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const couponInput = new TextInputBuilder()
                .setCustomId('coupon')
                .setLabel('Cupom de desconto (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false);

            const firstRow = new ActionRowBuilder().addComponents(emailInput);
            const secondRow = new ActionRowBuilder().addComponents(couponInput);

            modal.addComponents(firstRow, secondRow);
            await interaction.showModal(modal);
        } catch (error) {
            console.error('Erro ao processar compra:', error);
            await interaction.reply({ content: 'Erro ao processar compra!', ephemeral: true });
        }
    }

    async processPurchaseModal(interaction, productId) {
        try {
            const email = interaction.fields.getTextInputValue('email');
            const couponCode = interaction.fields.getTextInputValue('coupon') || null;

            const product = await this.database.getProduct(productId);
            if (!product) {
                return await interaction.reply({ content: 'Produto não encontrado!', ephemeral: true });
            }

            let finalPrice = product.price;
            let coupon = null;

            if (couponCode) {
                coupon = await this.database.getCoupon(couponCode);
                if (coupon && coupon.active && coupon.uses_left > 0) {
                    if (coupon.type === 'percentage') {
                        finalPrice = product.price * (1 - coupon.value / 100);
                    } else {
                        finalPrice = Math.max(0, product.price - coupon.value);
                    }
                }
            }

            // Criar pagamento no Mercado Pago
            const payment = await this.mercadoPago.createPayment({
                productId,
                userId: interaction.user.id,
                email,
                amount: finalPrice,
                description: product.name,
                couponId: coupon?.id
            });

            const embed = new EmbedBuilder()
                .setTitle('💳 Pagamento Criado')
                .setDescription(`**Produto:** ${product.name}\n**Valor:** R$ ${finalPrice.toFixed(2)}`)
                .addFields(
                    { name: '📱 PIX', value: `\`\`\`${payment.pix_code}\`\`\``, inline: false },
                    { name: '🔗 Link de Pagamento', value: `[Clique aqui](${payment.payment_url})`, inline: false }
                )
                .setColor('#00ff00')
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });

            // Salvar venda no banco
            await this.database.createSale({
                user_id: interaction.user.id,
                product_id: productId,
                amount: finalPrice,
                payment_id: payment.id,
                status: 'pending',
                email,
                coupon_id: coupon?.id
            });

        } catch (error) {
            console.error('Erro ao processar modal de compra:', error);
            await interaction.reply({ content: 'Erro ao processar compra!', ephemeral: true });
        }
    }

    async handleTicketCreation(interaction, category) {
        const modal = new ModalBuilder()
            .setCustomId(`ticket_${category}`)
            .setTitle('Criar Ticket de Suporte');

        const subjectInput = new TextInputBuilder()
            .setCustomId('subject')
            .setLabel('Assunto')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const descriptionInput = new TextInputBuilder()
            .setCustomId('description')
            .setLabel('Descrição do problema')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        const firstRow = new ActionRowBuilder().addComponents(subjectInput);
        const secondRow = new ActionRowBuilder().addComponents(descriptionInput);

        modal.addComponents(firstRow, secondRow);
        await interaction.showModal(modal);
    }

    async processTicketModal(interaction, category) {
        try {
            const subject = interaction.fields.getTextInputValue('subject');
            const description = interaction.fields.getTextInputValue('description');

            const guild = interaction.guild;
            const supportCategory = guild.channels.cache.get(process.env.SUPPORT_CATEGORY_ID);

            if (!supportCategory) {
                return await interaction.reply({ content: 'Categoria de suporte não configurada!', ephemeral: true });
            }

            const ticketChannel = await guild.channels.create({
                name: `ticket-${interaction.user.username}`,
                type: 0,
                parent: supportCategory.id,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    },
                ],
            });

            const embed = new EmbedBuilder()
                .setTitle('🎫 Ticket de Suporte')
                .setDescription(`**Usuário:** ${interaction.user}\n**Categoria:** ${category}\n**Assunto:** ${subject}\n**Descrição:** ${description}`)
                .setColor('#0099ff')
                .setTimestamp();

            const closeButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('close_ticket')
                        .setLabel('Fechar Ticket')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒')
                );

            await ticketChannel.send({ embeds: [embed], components: [closeButton] });

            await this.database.createTicket({
                user_id: interaction.user.id,
                channel_id: ticketChannel.id,
                category,
                subject,
                description,
                status: 'open'
            });

            await interaction.reply({ content: `Ticket criado: ${ticketChannel}`, ephemeral: true });
        } catch (error) {
            console.error('Erro ao criar ticket:', error);
            await interaction.reply({ content: 'Erro ao criar ticket!', ephemeral: true });
        }
    }

    async handleTicketClose(interaction) {
        try {
            const ticket = await this.database.getTicketByChannel(interaction.channel.id);
            if (!ticket) {
                return await interaction.reply({ content: 'Ticket não encontrado!', ephemeral: true });
            }

            await this.database.updateTicket(ticket.id, { status: 'closed' });
            await interaction.reply('Ticket será fechado em 5 segundos...');
            
            setTimeout(async () => {
                await interaction.channel.delete();
            }, 5000);
        } catch (error) {
            console.error('Erro ao fechar ticket:', error);
            await interaction.reply({ content: 'Erro ao fechar ticket!', ephemeral: true });
        }
    }

    async handleVerification(interaction) {
        try {
            const member = interaction.member;
            const verifiedRole = interaction.guild.roles.cache.find(role => role.name === 'Verificado');
            
            if (!verifiedRole) {
                return await interaction.reply({ content: 'Cargo de verificado não encontrado!', ephemeral: true });
            }

            if (member.roles.cache.has(verifiedRole.id)) {
                return await interaction.reply({ content: 'Você já está verificado!', ephemeral: true });
            }

            await member.roles.add(verifiedRole);
            await interaction.reply({ content: '✅ Você foi verificado com sucesso!', ephemeral: true });
        } catch (error) {
            console.error('Erro na verificação:', error);
            await interaction.reply({ content: 'Erro ao verificar usuário!', ephemeral: true });
        }
    }

    async handleWelcome(member) {
        try {
            const welcomeChannel = member.guild.channels.cache.get(process.env.WELCOME_CHANNEL_ID);
            if (!welcomeChannel) return;

            const embed = new EmbedBuilder()
                .setTitle('🎉 Bem-vindo!')
                .setDescription(`Olá ${member}, seja bem-vindo ao nosso servidor!\n\nClique no botão abaixo para se verificar e ter acesso completo.`)
                .setColor('#00ff00')
                .setThumbnail(member.user.displayAvatarURL())
                .setTimestamp();

            const verifyButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('verify')
                        .setLabel('Verificar-se')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅')
                );

            await welcomeChannel.send({ embeds: [embed], components: [verifyButton] });
        } catch (error) {
            console.error('Erro ao enviar mensagem de boas-vindas:', error);
        }
    }

    async start() {
        await this.client.login(process.env.DISCORD_TOKEN);
    }
}

const bot = new SalesBot();
bot.start().catch(console.error);

